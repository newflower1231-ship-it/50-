const http=require('http'),fs=require('fs'),crypto=require('crypto');
const questions=JSON.parse(fs.readFileSync(__dirname+'/questions.json','utf8'));
const PORT=Number(process.env.PORT||3000),PIN=process.env.TEACHER_PIN||'2468';
const names=['Улаан','Цэнхэр','Ногоон','Шар','Ягаан','Улбар'];
const codes=names.map(()=>crypto.randomBytes(3).toString('hex').toUpperCase());
const teams=names.map((name,i)=>({name,code:codes[i],money:0}));
let active=null,used=[],answers=[],reveal=false,deadline=0,round=0,teacherTokens=new Set();
const money={100:500000,200:1000000,300:1500000,400:2000000,500:5000000};
const send=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data))};
function safeState(role,team){let q=active&&questions[active.c].q[active.i];return {role,team,teams:teams.map((t,i)=>({name:t.name,money:t.money,index:i})),categories:questions.map((c,i)=>({name:c.name,points:c.q.map((_,j)=>(j+1)*100)})),used,round,active:active&&{c:active.c,i:active.i,points:(active.i+1)*100,question:q[0],options:q[1],deadline},reveal,correct:reveal&&q?q[2]:null,explanation:reveal&&q?q[3]:null,answers:role==='teacher'?answers.map(a=>({...a,correct:reveal?q&&a.choice===q[2]:null})):undefined,myAnswer:role==='team'?answers.find(a=>a.team===team)||null:undefined,received:answers.length,serverTime:Date.now()}}
function identify(req,body){let token=req.headers.authorization?.replace(/^Bearer /,'')||body.token;if(teacherTokens.has(token))return {role:'teacher'};let team=teams.findIndex(t=>t.code===token);return team>=0?{role:'team',team}:{role:'guest'}}
const fail=(res,msg,code=400)=>send(res,code,{error:msg});
const server=http.createServer(async(req,res)=>{let path=new URL(req.url,'http://localhost').pathname;
 if(req.method==='GET'&&path==='/'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});return fs.createReadStream(__dirname+'/index.html').pipe(res)}
 if(req.method==='GET'&&path==='/health')return send(res,200,{ok:true});
 if(path!=='/api')return fail(res,'Хуудас олдсонгүй',404);
 let body={};if(req.method==='POST'){try{let chunks=[];for await(const ch of req){chunks.push(ch);if(Buffer.concat(chunks).length>20000)throw Error('too large')}body=JSON.parse(Buffer.concat(chunks).toString()||'{}')}catch{return fail(res,'Өгөгдөл буруу')}}
 const id=identify(req,body),act=body.action;
 if(req.method==='GET')return send(res,200,safeState(id.role,id.team));
 if(act==='loginTeacher'){if(String(body.pin)!==PIN)return fail(res,'Багшийн PIN буруу',403);let token=crypto.randomBytes(24).toString('hex');teacherTokens.add(token);return send(res,200,{token,role:'teacher'})}
 if(act==='loginTeam'){let i=teams.findIndex(t=>t.code===String(body.code||'').trim().toUpperCase());if(i<0)return fail(res,'Багийн код буруу',403);return send(res,200,{token:teams[i].code,role:'team',team:i})}
 if(id.role==='guest')return fail(res,'Эхлээд нэвтэрнэ үү',401);
 if(act==='answer'){if(id.role!=='team')return fail(res,'Зөвхөн баг хариулна',403);if(!active||reveal||Date.now()>deadline)return fail(res,'Хариулах хугацаа дууссан');if(answers.some(a=>a.team===id.team))return fail(res,'Энэ асуултад хариулсан байна');if(![0,1,2].includes(body.choice))return fail(res,'Хариулт буруу');answers.push({team:id.team,choice:body.choice,ms:Date.now(),order:answers.length+1});return send(res,200,{ok:true})}
 if(id.role!=='teacher')return fail(res,'Зөвхөн багш удирдана',403);
 if(act==='open'){let c=Number(body.c),i=Number(body.i);if(!Number.isInteger(c)||!Number.isInteger(i)||!questions[c]?.q[i])return fail(res,'Асуулт олдсонгүй');if(active&&!reveal)return fail(res,'Өмнөх асуултаа эхлээд шалгана уу');if(used.includes(c+'-'+i))return fail(res,'Энэ асуулт тоглогдсон');let seconds=Math.max(10,Math.min(180,Number(body.seconds)||30));active={c,i};answers=[];reveal=false;deadline=Date.now()+seconds*1000;round++;return send(res,200,{ok:true})}
 if(act==='reveal'){if(!active)return fail(res,'Нээлттэй асуулт алга');if(reveal)return fail(res,'Шалгасан байна');reveal=true;let q=questions[active.c].q[active.i],correct=answers.filter(a=>a.choice===q[2]).sort((a,b)=>a.ms-b.ms);for(let a of correct){teams[a.team].money+=money[(active.i+1)*100]+(a===correct[0]?1000000:0)}used.push(active.c+'-'+active.i);return send(res,200,{ok:true})}
 if(act==='reset'){if(body.confirm!=='RESET')return fail(res,'Баталгаажуулалт хэрэгтэй');active=null;used=[];answers=[];reveal=false;deadline=0;round++;teams.forEach(t=>t.money=0);return send(res,200,{ok:true})}
 if(act==='close'){if(active&&!reveal)return fail(res,'Эхлээд хариултыг шалгана уу');active=null;answers=[];reveal=false;deadline=0;return send(res,200,{ok:true})}
 if(act==='rename'){let i=Number(body.team);if(!teams[i])return fail(res,'Баг олдсонгүй');teams[i].name=String(body.name||'').trim().slice(0,35)||names[i];return send(res,200,{ok:true})}
 if(act==='codes')return send(res,200,{codes:teams.map(t=>({name:t.name,code:t.code}))});
 return fail(res,'Үйлдэл олдсонгүй');
});server.listen(PORT,'0.0.0.0',()=>console.log('50 саяын өсөлт :'+PORT));
